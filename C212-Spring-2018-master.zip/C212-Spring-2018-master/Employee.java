public interface Employee {
	//interface for Manager and Server to extend
	
	abstract String getName();
	abstract int getUserID();
	abstract String getPassword();
	abstract double getWage();
	abstract String getPosition();
	
	
}